
export async function makeRoute(payload) {
	const res = await fetch('http://Kags-backend-env.eba-ys7uyk8y.us-east-2.elasticbeanstalk.com/api/navigation', {
		method: 'POST',
		headers: { 'Content-Type': 'application/json' },
		body: JSON.stringify(payload)
	})

	return res.json()
}